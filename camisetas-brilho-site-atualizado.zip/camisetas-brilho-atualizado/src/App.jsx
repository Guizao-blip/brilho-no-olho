import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { motion } from "framer-motion";

export default function CamisetaSite() {
  const [tempoRestante, setTempoRestante] = useState(0);

  useEffect(() => {
    const fimCampanha = new Date();
    fimCampanha.setDate(fimCampanha.getDate() + 28);
    const intervalo = setInterval(() => {
      const agora = new Date();
      const diff = fimCampanha - agora;
      setTempoRestante(Math.max(0, Math.floor(diff / 1000)));
    }, 1000);
    return () => clearInterval(intervalo);
  }, []);

  const dias = Math.floor(tempoRestante / 86400);
  const horas = Math.floor((tempoRestante % 86400) / 3600);
  const minutos = Math.floor((tempoRestante % 3600) / 60);
  const segundos = tempoRestante % 60;

  return (
    <div className="min-h-screen bg-white text-gray-800">
      {/* Header */}
      <header className="sticky top-0 bg-white shadow-md z-50">
        <div className="max-w-6xl mx-auto p-4 flex justify-between items-center">
          <h1 className="text-xl font-bold">Brilho no Olho</h1>
          <nav className="space-x-4">
            <a href="#sobre" className="hover:underline">Sobre</a>
            <a href="#camisetas" className="hover:underline">Camisas</a>
            <a href="#depoimentos" className="hover:underline">Depoimentos</a>
            <a href="#comprar" className="hover:underline">Compre Agora</a>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gray-100 py-20 text-center" id="sobre">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-3xl font-bold mb-4">Você sobreviveu. Agora vista a sua conquista.</h2>
          <p className="mb-6">A camiseta que celebra sua jornada pelo Ensino Médio com estilo e orgulho.</p>
          <div className="text-2xl font-mono mb-6">
            Faltam {dias}d {horas}h {minutos}m {segundos}s para o fim da campanha
          </div>
          <Button size="lg">Quero a minha agora</Button>
        </div>
      </section>

      {/* Camisetas */}
      <section id="camisetas" className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <h3 className="text-2xl font-bold text-center mb-10">Nossas Camisetas</h3>
          <div className="grid md:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="hover:shadow-xl transition-shadow">
                <CardContent className="p-4">
                  <img src={`/camiseta${i}.jpg`} alt={`Camiseta ${i}`} className="mb-4 rounded-xl" />
                  <h4 className="font-semibold">Camiseta Edição Limitada</h4>
                  <p className="text-sm text-gray-600">100% algodão, estampa premium, super confortável.</p>
                  <p className="text-lg font-bold mt-2">De R$119,90 por <span className="text-green-600">R$89,90</span></p>
                  <Button className="mt-3 w-full">Comprar Agora</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Depoimentos */}
      <section id="depoimentos" className="bg-gray-50 py-16">
        <div className="max-w-4xl mx-auto px-4">
          <h3 className="text-2xl font-bold text-center mb-10">Quem já comprou, amou</h3>
          <div className="space-y-6">
            <blockquote>
              <p className="italic">“Quando chegou, chorei. Não é só uma camiseta — é minha história estampada.”</p>
              <cite className="block mt-2 font-semibold">— Mariana R.</cite>
            </blockquote>
            <blockquote>
              <p className="italic">“Super confortável, linda e com um significado incrível. Comprei duas!”</p>
              <cite className="block mt-2 font-semibold">— João P.</cite>
            </blockquote>
          </div>
        </div>
      </section>

      {/* Comprar */}
      <section id="comprar" className="py-16 bg-white">
        <div className="max-w-md mx-auto px-4">
          <h3 className="text-xl font-bold text-center mb-4">Garanta a sua agora</h3>
          <form className="space-y-4">
            <Input placeholder="Nome completo" required />
            <Input placeholder="E-mail" required />
            <Input placeholder="Endereço de entrega" required />
            <Input placeholder="Forma de pagamento" required />
            <Button type="submit" className="w-full">Finalizar compra</Button>
          </form>
        </div>
      </section>

      {/* Rodapé */}
      <footer className="bg-gray-100 text-center py-6 text-sm">
        <p>© 2025 Brilho no Olho. Todos os direitos reservados.</p>
        <p>Fale com a gente no WhatsApp • Siga no Instagram @brilhonoolho</p>
      </footer>
    </div>
  );
}